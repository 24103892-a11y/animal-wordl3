# CSS Week 1 Homework — Không Gian Xanh

Website gồm 3 trang HTML và một stylesheet CSS dùng chung.

## Tệp
- `index.html`: trang chủ
- `neighborhood.html`: trang khu phố
- `parks.html`: trang công viên (có hơn 5 hình ảnh)
- `style.css`: CSS dùng chung
- `images/`: hình minh họa SVG tự tạo, lưu cục bộ

## Yêu cầu được áp dụng
- Cấu trúc HTML5, thẻ ngữ nghĩa, danh sách, liên kết ngoài.
- Liên kết bỏ qua nội dung chính, chỉ hiện khi nhận focus bằng bàn phím.
- Điều hướng flex có màu nền, khoảng cách, bo góc và hiệu ứng hover/focus.
- Ảnh có viền, padding, border-radius.
- CSS Grid hai cột trở lên và Flexbox với wrap/justify-content.
- Hiệu ứng hover và bộ chọn `:nth-child()`.
- Văn bản thay thế `alt` cho ảnh; liên kết mở tab mới có `rel="noopener noreferrer"`.

## Cách đưa lên GitHub
1. Giải nén file ZIP trên máy tính.
2. Mở repository **thuộc tài khoản GitHub của bạn** (không phải repository giảng viên hoặc repository mà bạn chỉ có quyền tạo Pull Request).
3. Chọn `Add file` → `Upload files`.
4. Tải lên các file bên trong thư mục `CSS-week2-HW`, bao gồm `index.html`, `neighborhood.html`, `parks.html`, `style.css` và thư mục `images` sao cho cấu trúc trên GitHub giữ nguyên.
5. Bấm `Commit changes` để lưu vào nhánh đang triển khai GitHub Pages.
6. Nếu GitHub Pages đang dùng nhánh `main` và thư mục gốc, link dự kiến của trang chủ là:
   `https://TEN-TAI-KHOAN.github.io/TEN-REPOSITORY/CSS-week2-HW/`
   Hãy thay hai phần viết hoa bằng username và tên repository thực tế. Link chỉ hoạt động sau khi các tệp được lưu vào repository đúng và Pages đã triển khai.

## Kiểm tra trước khi nộp
- Xác thực từng trang bằng https://validator.w3.org/.
- Sau khi website online, dán URL vào https://wave.webaim.org/ để kiểm tra khả năng truy cập.
